

//Huffman Encoding - C Program Source code for generating Huffman Codes

#include<string.h>
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>
//user defined data type for heap
typedef struct node
{
        char ch;
        int freq;
        struct node *left;
        struct node *right;
}node;
//user defined data type for storing letters
typedef struct __letter
{
    char ch;                                //save character
    char code[513];                         //save corresponding huffman code for ch
}letter;                                    //name of struct
/*Declaring heap globally so that we do not need to pass it as an argument every time*/
/* Heap implemented  here is Min Heap */
node * heap[10];                            //double array of heap declared with one of its size 10
int heapSize;
int counter=0;
/*Initialize Heap*/
void Init()
{
        heapSize = 0;
        heap[0] = (node *)malloc(sizeof(node));     //new memory is allocated whose address is at heap[0]
        heap[0]->freq = -INT_MAX;                   //frequency set to -2147483647
}
/*Insert an element into the heap */
void Insert(node * element)
{
        heapSize++;
        heap[heapSize] = element; /*Insert in the last place*/
        /*Adjust its position*/
        int now = heapSize;
        while(heap[now/2] -> freq > element -> freq) 
        {
                heap[now] = heap[now/2];
                now /= 2;
        }
        heap[now] = element;
}
node * DeleteMin()
{
        /* heap[1] is the minimum element. So we remove heap[1]. Size of the heap is decreased. 
           Now heap[1] has to be filled. We put the last element in its place and see if it fits.
           If it does not fit, take minimum element among both its children and replaces parent with it.
           Again See if the last element fits in that place.*/
        node * minElement,*lastElement;
        int child,now;
        minElement = heap[1];
        lastElement = heap[heapSize--];
        /* now refers to the index at which we are now */
        for(now = 1; now*2 <= heapSize ;now = child)
        {
                /* child is the index of the element which is minimum among both the children */ 
                /* Indexes of children are i*2 and i*2 + 1*/
                child = now*2;
                /*child!=heapSize beacuse heap[heapSize+1] does not exist, which means it has only one 
                  child */
                if(child != heapSize && heap[child+1]->freq < heap[child] -> freq ) 
                {
                        child++;
                }
                /* To check if the last element fits ot not it suffices to check if the last element
                   is less than the minimum element among both the children*/
                if(lastElement -> freq > heap[child] -> freq)
                {
                        heap[now] = heap[child];
                }
              else /* It fits there */
                {
                        break;
                }
        }
        heap[now] = lastElement;
        return minElement;
}
void print(node *temp,char *code,letter *let)
{
        if(temp->left==NULL && temp->right==NULL)   //checking for leaf node in heap
        {
                strcpy(let[counter].code,code);     //adding character from tree to let(variable with data type letter)
                let[counter].ch = temp->ch;         //assigning corresponding ch code to let
                counter++;                          //increment counter(counter keeps track of number of characters in array of let)
                printf("char %c code %s\n",temp->ch,code);
                return;
        }
        int length = strlen(code);                  //find length of code
        char leftcode[512],rightcode[512];
        strcpy(leftcode,code);
        strcpy(rightcode,code);
        leftcode[length] = '0';                     //Assigning 0 to
        leftcode[length+1] = '\0';                  // left node and append null at end
        rightcode[length] = '1';                    //Assigning 1 to
        rightcode[length+1] = '\0';                 // right node and append null at end
        print(temp->left,leftcode,let);
        print(temp->right,rightcode,let);
}
/*
    Get code for the string you will enter.
    The string will be in the form of 0's and 1's
*/
void get_code(letter *let)
{
    char str[1000];
    int j=0,i=0,k=0;
    printf("Enter the string(use characters whose frequency was entered before in this program):");
    scanf("%s",str);                //Store string in str
    printf("String is '%s' and decoded string is ",str);
    //Fetching the characters form str
    for (j=0;j<strlen(str);j++)
    {
        //Accessing every element in let
        for (i=0;i<counter;i++)          //counter holds the value of number of letters entered
        {
            if (let[i].ch == str[j])        //Matching characters in ith element if let and jth position of str
            {
                printf("%s",let[i].code);   //print the code for encountered letter
                k=1;                        //descision maker if 1 then character found
                break;
            }
            else
                    k=0;                    //If character not found
        }
        //Checking the validity of Character
        if (k==0)
        {
            printf("An unknown character encountered");
            exit(0);                         //exit from the program
        }
    }
    printf("\n");                            //print new line at the end of decoded string
}
/*
    Get the decoded string from encoded string
*/
void get_str(node *let)
{
    char str[512];
    int i=0,j=0,k=0,l=0,desc=0,len;
    printf("Enter code to be decoded:");
    scanf("%s",str);
    node *temp = let;              //Assign the address of root node to temp
    //Validate the string
    for (i=0;i<strlen(str);i++)
    {
        if (str[i] != '1' && str[i] !='0')    //check if string (str) contains 0's and 1's
        {
            printf("\nInvalid string,program is exiting");
            return ;                          //Return if string contains and non 0 and non 1 characters
        }
    }
    printf("Decoded string is:");
    //start decodeing by traversing tree
    for (i=0;i<strlen(str);i++)               //scanf every character in string
    {
            if (str[i] == '1')                //If character is 1 then enter if condition
            {
                temp = temp->right;           //traverse to the right of heap
                if (temp->right == '\0')      //If right child of temp is NULL then  
                {                             //print character (ch) at temp
                        printf("%c",temp->ch);
                        temp=let;             //go to start of the tree(root node)
                }
            }
            else if (str[i] == '0')              //If character is 0 then enter if condition
            {
                temp = temp->left;               //traverse to the left of heap
                if (temp->left == '\0')          //If left child of temp is NULL then  
                {                                //print character (ch) at temp
                        printf("%c",temp->ch);  
                        temp=let;                //go to start of the tree(root node)
                }
            }
    }

}
/* Given the list of characters along with their frequencies, our goal is to predict the encoding of the
   characters such that total length of message when encoded becomes minimum */ 
int main()
{
        Init();
        int distinct_char ;
		printf("First Enter the number of element char you want to insert :");
        scanf("%d",&distinct_char);
		printf("Now Enter the char and its frequency ");
        char ch;
        int freq;       
        int iter;
        for(iter=0;iter<distinct_char;iter++)
        {
                char t[4];

                scanf("%s",t); //Scanning the character as string to avoid formatting issues of input.

                ch = t[0];
                scanf("%d",&freq);
                node * temp = (node *) malloc(sizeof(node));
                temp -> ch = ch;
                temp -> freq = freq;
                temp -> left = temp -> right = NULL;
                Insert(temp);
        }
        /* Special Case */
        if(distinct_char==1)
        {
                printf("char %c code 0\n",ch);
                return 0;
        }
        for(iter=0;iter<distinct_char-1 ;iter++)
        {
                node * left = DeleteMin();
                node * right = DeleteMin();
                node * temp = (node *) malloc(sizeof(node));
                temp -> ch = 0;
                temp -> left = left;
                temp -> right = right;
                temp -> freq = left->freq + right -> freq;
                Insert(temp);
        }
        node *tree = DeleteMin();
        char code[512];
        code[0] = '\0';
        letter *let = (letter *)calloc(distinct_char,sizeof(letter));
        print(tree,code,let);
        int op;
        while (1)
        {
            printf("\nMenu\n1.Encode String\n2.Decode String\n3.Exit\n enter option number:");
            scanf("%d",&op);
            switch (op)
            {
                case 1:get_code(let);break;
                case 2:get_str(tree);break;
                case 3:exit(0);
                default:
                    printf("You have entered wrong option,try again");
            }
        }
}


/*-------------------------OUTPUT--------------------------

administrator@administrator-dx2480-MT:~/Desktop$ gcc -g HUFFMAN.c 
administrator@administrator-dx2480-MT:~/Desktop$ ./a.out 
First Enter the number of element char you want to insert :5 
Now Enter the char and its frequency k 1 
u 1 
n 1 
a 1 
l 1 
char k code 00 
char l code 01 
char n code 10 
char a code 110 
char u code 111 

Menu 
1.Encode String 
2.Decode String 
3.Exit 
 enter option number:1 
Enter the string(use characters whose frequency was entered before in this program):kunal 
String is 'kunal' and decoded string is 001111011001 

Menu 
1.Encode String 
2.Decode String 
3.Exit 
 enter option number:2 
Enter code to be decoded:0010110 
Decoded string is:kna 
Menu 
1.Encode String 
2.Decode String 
3.Exit 
 enter option number:3 
administrator@administrator-dx2480-MT:~/Desktop$ 

*/
