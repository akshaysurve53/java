#include<stdio.h>
#include<math.h>
int n1;
int padding(int n1);
void stras(int a[][n1],int b[][n1],int c[][n1],int size);
void main()
{
       printf("Enter the size of matrix:-\n");
	scanf("%d",&n1);
	
	int i,j,size,k;
	size=n1;
	k=size;
	n1=padding(n1);
	int a[n1][n1],b[n1][n1],c[n1][n1];
printf("Enter the 1st matrix:-\n");

	for(i=0;i<size;i++)

	for(j=0;j<size;j++)
			scanf("%d",&a[i][j]);

	printf("Enter the 2nd matrix:-\n");
	
	for(i=0;i<size;i++)
	{
		for(j=0;j<size;j++)
			{
			    scanf("%d",&b[i][j]);
			    
			}
	    
	}
	for(i=size;i<n1;i++)
	{
		for(j=0;j<n1;j++)
			{
				a[i][j]=0;
				b[i][j]=0;
			}
	}
	for(i=0;i<n1;i++)
	{
		for(j=size;j<n1;j++)
			{
				a[i][j]=0;
				b[i][j]=0;
			}
	}
		printf("\n  matrix a is \n");
		for(i=0;i<n1;i++)
	{
		for(j=0;j<n1;j++)
		{
			printf("%d",a[i][j]);
			printf("\t");
		}
		printf("\n");
	}
			printf("\n  matrix b is \n");
	for(i=0;i<n1;i++)
	{
		for(j=0;j<n1;j++)
		{
			printf("%d",b[i][j]);
			printf("\t");
		}
		printf("\n");
	}


	stras(a,b,c,n1);

	printf("\n  matrix c is \n");
	for(i=0;i<k;i++)
	{
		for(j=0;j<k;j++)
		{
			printf("%d",c[i][j]);
			printf("\t");
		}
		printf("\n");
	}
}
int padding(int n1)
{
	int count=0,i,T=1;
	i=n1;
	while(i>1)
	{
		i=i/2;
		floor(i);		//calculates the nearest integer less than the argument passed.
		count++;
	}
	for(i=0;i<count;i++)
	{
		T=T*2;
	}
	
	if(n1==T)
	{
		return n1;
	}
	
	else
	{T=T*2;
	return T;}
}
void stras(int a[][n1],int b[][n1],int c[][n1],int size)
{
	int i,j,n;
	n=size/2;
	int m1[n][n],m2[n][n],m3[n][n],m4[n][n],m5[n][n],m6[n][n],m7[n][n];
	int temp1[n][n],temp2[n][n];
	

	if(size>=2)
	{
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i][j]+a[i+n][j+n];
			temp2[i][j]=b[i][j]+b[i+n][j+n];
		}
		n1=size/2;
		stras(temp1,temp2,m1,n1);
/////////////////////////////////////////////////////
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i+n][j]+a[i+n][j+n];
			temp2[i][j]=b[i][j];
		}
		
		n1=size/2;
		stras(temp1,temp2,m2,n1);
////////////////////////////////////////////////////////////////
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i][j];
			temp2[i][j]=b[i][j+n]-b[i+n][j+n];
		}
		
		n1=size/2;
		stras(temp1,temp2,m3,n1);
///////////////////////////////////////////////////
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i+n][j+n];
			temp2[i][j]=b[i+n][j]-b[i][j];
		}
		
		n1=size/2;
		stras(temp1,temp2,m4,n1);
////////////////////////////////////////////////////////////
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i][j]+a[i][j+n];
			temp2[i][j]=b[i+n][j+n];
		}

		n1=size/2;
		stras(temp1,temp2,m5,n1);
///////////////////////////////////////////////////
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i+n][j]-a[i][j];
			temp2[i][j]=b[i][j]+b[i][j+n];
		}
		n1=size/2;
		stras(temp1,temp2,m6,n1);
//////////////////////////////////////////////////////////
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			temp1[i][j]=a[i][j+n]-a[i+n][j+n];
			temp2[i][j]=b[i+n][j]+b[i+n][j+n];
		}

		n1=size/2;
		stras(temp1,temp2,m7,n1);		
////////////////////////////////////////////////////////////////	
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
		{
			c[i][j]=m1[i][j]+m4[i][j]-m5[i][j]+m7[i][j];
			c[i][j+n]=m3[i][j]+m5[i][j];
			c[i+n][j]=m2[i][j]+m4[i][j];
			c[i+n][j+size/2]=m1[i][j]+m3[i][j]-m2[i][j]+m6[i][j];
		}
	}

	else if(size==1)
		c[0][0]=a[0][0] * b[0][0];

}





/*
OUTPUT:
Enter the size of matrix:-
3
Enter the 1st matrix:-
1 2 3
4 5 6
7 8 9
Enter the 2nd matrix:-
9 8 7
6 5 4
3 2 1

  matrix a is 
1	2	3	0	
4	5	6	0	
7	8	9	0	
0	0	0	0	

  matrix b is 
9	8	7	0	
6	5	4	0	
3	2	1	0	
0	0	0	0	

  matrix c is 
30	24	18	
84	69	54	
138	114	90	*/	
