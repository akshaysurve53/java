#include<stdio.h>  
#include<stdlib.h> 
#include<time.h> 
static int cnt=1,x[10]; 
int place(int k,int i) 
{ 
	int j; 
  	for(j=1;j<k;j++) 
   	if((x[j]==i)||(abs(x[j]-i)==abs(j-k))) 
	return(0); 
return(1); 
} 

void chessprint(int n) 
{ 
	int i,j; 
  	printf("\nSolution :- %d\n\n    ",cnt++); 
  	for(i=1;i<=n;i++) 
  	{ 
   		printf("\n\n%d   ",i); 
   		for(j=1;j<=n;j++) 
   		{ 
			if(j==x[i]) 
				printf("Q   "); 
			else 
				printf("_   "); 
   		} 
  	} 
} 

void NQueen(int k, int n) 
{ 
  	int i,j; 
	for(i=1;i<=n;i++) 
  	{ 
		if(place(k,i)) 
		{ 
	  		x[k]=i; 
	  		if(k==n) 
	  		{ 
				chessprint(n) ; 
			} 
	  		else 
	  		NQueen(k+1,n); 
		} 
  	} 
} 

void main() 
{ 
	int n; 
  	printf("Enter no of Queens:  "); 
  	scanf("%d",&n);  
  	NQueen(1,n);
}

/*
administrator@IT-SL1-17:~$ cd Desktop
administrator@IT-SL1-17:~/Desktop$ gcc qn.c 
administrator@IT-SL1-17:~/Desktop$ ./a.out
Enter no of Queens:  4

Solution :- 1

    

1   _   Q   _   _   

2   _   _   _   Q   

3   Q   _   _   _   

4   _   _   Q   _   
Solution :- 2

    

1   _   _   Q   _   

2   Q   _   _   _   

3   _   _   _   Q   

4   _   Q   _   _  

 administrator@IT-SL1-17:~/Desktop$ */	
