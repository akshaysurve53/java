 #include<stdio.h> 
#include<stdlib.h> 
#define MAX 30 
int x[MAX]; 
int NextValue(int graph[MAX][MAX],int n,int k) 
{ 
	int j; 
	while(1) 
	{ 
		x[k] = (x[k]+1)%(n+1); // obtain next vertex 
		if(x[k]==0) 
			return; 
			 
		if(graph[x[k-1]][x[k]]!=0) 
		{	//if edge between k and k-1 is present 
			for(j=1;j<=k-1;j++) // every adjacent vertex 
			{ 
				if(x[j]==x[k]) // not a distinct vertex 
					break; 
			} 
			if(j==k) // to get a distinct value 
			{ 
				if((k<n)||((k==n)&&(graph[x[n]][x[1]]!=0))) 
					return; // return a distinct vertex 
			} 
		} 
	} 
} 
void Hamiltonian(int graph[][MAX],int n,int k) 
{ 
	int i; 
	 
	while(k) 
	{ 
		if(NextValue(graph,n,k)) // generates next vertex for determining cycle 
		{ 
			if(x[k]==0) 
				return; 
			 
			if(k==n) 
			{ 
				printf("\n"); 
			 
				for(i=1;i<=n;i++) 
					printf("%d-->",x[i]); // print the hamiltonian cycle 
				printf("%d",x[1]); 
			} 
			k=k+1; 
		} 
		else 
			 
		k=k-1; 
			 
			 
	} 
	 
	 
} 
void main() 
{ 
	int i,j,vertex1,vertex2,edges,n,graph[MAX][MAX]; 
	 
	printf("\n\n*********** HAMILTONIAN CYCLE ************\n"); 
	printf("\nEnter the number of vertices of the graph : "); 
	scanf("%d",&n); 
	 
	for(i=1;i<=n;i++) 
	{ 
		for(j=1;j<=n;j++) 
		{ 
			graph[i][j]=0; 
			x[i]=0; 
		} 
	} 
	 
	printf("\n\nEnter the total number of edges : "); 
	scanf("%d",&edges); 
	 
	 
	 
	for(i=1;i<=edges;i++) 
	{ 
		printf("\nEnter the edge : "); 
		scanf("%d%d",&vertex1,&vertex2); 
		graph[vertex1][vertex2]=1; 
		graph[vertex2][vertex1]=1; 
	} 
	 
	x[1]=1; 
	 
	printf("\n\nThe Hamiltonian cycle : \n"); 
	Hamiltonian(graph,n,2); 
} 
