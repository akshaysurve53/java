#include<stdio.h> 
#include<stdlib.h> 
void floydWarshall(int size,int mat[10][10]) 
{ 
	int i,j,k,d[size][size],n1,n2,s=999; 
	for(i=0;i<size;i++) 
	{ 
		for(j=0;j<size;j++) 
		{ 
			d[i][j]=mat[i][j]; 
		} 
	} 
	 
	for(k=0;k<size;k++)			// INTERMEDIATE NODE 
	{ 
		for(i=0;i<size;i++)		//ROW 
		{ 
			for(j=0;j<size;j++)	//COLUMN 
			{ 
				if((d[i][k]+d[k][j])<d[i][j]) 
				{ 
					d[i][j]=d[i][k]+d[k][j]; 
				} 
			} 
		} 
	} 
	for(i=0;i<size;i++) 
	{ 
		for(j=0;j<size;j++) 
		{ 
			printf("%d\t",d[i][j]); 
		} 
		printf("\n"); 
	}
	for(i=0;i<size;i++) // ...FINDING SHORTEST PATH...
	{ 
		for(j=0;j<size;j++) 
		{ 
			if(i!=j) 
			{ 
				if(s>d[i][j]) 
				{ 
					s=d[i][j]; 
					n1=i+1; 
					n2=j+1; 
				} 
			} 
		} 
	} 
	printf("\n\nTHE SHORTEST PATH IS FROM NODE %d -> %d WITH WEIGHT %d\n",n1,n2,s); 
} 

void main() 
{ 
	int mat[10][10],i,j,size,k; 
	 
	printf("Enter the number of vertices: "); 
	scanf("%d",&size); 
	 
	for(i=0;i<size;i++) 
	{ 
		mat[i][i]=0; 
	} 
	 
	printf("Enter the values in matrix[for infinity enter 999]"); 
	 
	for(i=0;i<size;i++) 
	{ 
		for(j=0;j<size;j++) 
		{ 
			if(i!=j) 
			{ 
				printf("\nmat[%d][%d]: ",i+1,j+1); 
				scanf("%d",&mat[i][j]); 
			} 
		} 
	} 
	 
	for(i=0;i<size;i++) 
	{ 
		for(j=0;j<size;j++) 
		{ 
			printf("%d\t",mat[i][j]); 
		} 
		printf("\n"); 
	} 
	printf("\n\nTHE SHORTEST PATH IS:\n\n"); 
		 
	floydWarshall(size,mat); 
} 
